<?php

include_once ACADEMIST_CORE_CPT_PATH . '/team/team-register.php';
include_once ACADEMIST_CORE_CPT_PATH . '/team/helper-functions.php';