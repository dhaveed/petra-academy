<div class="eltdf-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
	<div class="eltdf-separator" <?php echo academist_elated_get_inline_style($holder_styles); ?>></div>
</div>
