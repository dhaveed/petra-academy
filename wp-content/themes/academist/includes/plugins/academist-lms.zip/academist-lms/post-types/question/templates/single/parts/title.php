<h5 class="eltdf-question-single-title">
	<?php echo get_the_title( $question_id ); ?>
</h5>