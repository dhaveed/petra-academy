<?php

include_once 'course-slider.php';
include_once 'helper-functions.php';
