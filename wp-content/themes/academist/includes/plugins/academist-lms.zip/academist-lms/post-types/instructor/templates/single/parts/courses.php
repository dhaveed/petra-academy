<?php

echo academist_elated_execute_shortcode( 'eltdf_course_list', $courses );