<?php

if ( function_exists( 'academist_membership_get_favorite_template' ) ) {
	academist_membership_get_favorite_template();
}