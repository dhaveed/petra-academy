<?php

include_once 'course-table.php';
include_once 'helper-functions.php';
