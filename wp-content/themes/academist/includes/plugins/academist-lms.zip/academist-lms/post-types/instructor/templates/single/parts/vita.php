<?php if ( ! empty( $vita ) ) { ?>
	<p class="eltdf-vita">
		<?php echo esc_html( $vita ); ?>
	</p>
<?php } ?>