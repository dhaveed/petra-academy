<div class="eltdf-course-content">
	<?php the_content(); ?>
</div>