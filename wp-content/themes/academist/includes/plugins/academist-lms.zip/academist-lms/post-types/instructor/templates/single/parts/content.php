<div class="eltdf-instructor-single-content">
	<?php the_content(); ?>
</div>