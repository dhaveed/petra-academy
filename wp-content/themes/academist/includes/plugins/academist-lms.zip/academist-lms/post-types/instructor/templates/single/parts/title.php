<?php if ( ! empty( $title ) ) { ?>
	<p class="eltdf-title">
		<?php echo esc_html( $title ); ?>
	</p>
<?php } ?>