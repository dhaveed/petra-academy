<?php

include_once ACADEMIST_LMS_CPT_PATH . '/quiz/quiz-register.php';
include_once ACADEMIST_LMS_CPT_PATH . '/quiz/helper-functions.php';