<?php

define( 'ACADEMIST_CHECKOUT_INTEGRATION', '1.1' );
define( 'ACADEMIST_CHECKOUT_INTEGRATION_PATH', dirname( __FILE__ ) );
define( 'ACADEMIST_CHECKOUT_INTEGRATION_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'ACADEMIST_CHECKOUT_INTEGRATION_URL_PATH', plugin_dir_url( __FILE__ ) );