<a href="#" class="eltdf-login-opener">
    <span class="eltdf-login-text"><?php esc_html_e('Login / Register', 'academist-membership'); ?></span>
</a>